/*!
\file    mixins.h
\brief   Some simple "mixin" helper classes.
\author  David Joffe

Copyright (C) 2000-2001 David Joffe

License: GNU GPL Version 2 (*not* "later versions")
*/
/*--------------------------------------------------------------------------*/
#ifndef _MIXINS_H_
#define _MIXINS_H_

class CNamed
{
  public:
   CNamed();

   void   SetName( char * szName );
   char * GetName();

   char * m_szName;
};

#endif
