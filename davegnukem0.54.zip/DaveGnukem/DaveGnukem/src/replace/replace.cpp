

#include <stdio.h>
#include <stdlib.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>

#ifdef WIN32
#include "io.h"
#else
#include <unistd.h>
#endif

#ifdef WIN32
#define FILECREATE_FLAGS (O_CREAT | O_TRUNC | O_BINARY | O_RDWR)
#define FILECREATE_PERM  (S_IWRITE | S_IREAD)
#define FILEOPEN_FLAGS   (O_RDWR | O_BINARY)
#else
#define FILECREATE_FLAGS (O_CREAT | O_TRUNC | O_RDWR)
#define FILECREATE_PERM  (S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH)
#define FILEOPEN_FLAGS   (0/*O_RDONLY*/)
#endif


#define LEVEL_WIDTH  128
#define LEVEL_HEIGHT 100
#define LEVEL_SIZE   (4 * LEVEL_WIDTH * LEVEL_HEIGHT)

int main(int argc, char *argv[])
{
	if (argc<6)
	{
		printf("Usage: replace levelfilename a1 b1 a2 b2\n");
		return -1;
	}

	char *szFilename = argv[1];
	unsigned char a1 = (unsigned char)atoi(argv[2]);
	unsigned char b1 = (unsigned char)atoi(argv[3]);
	unsigned char a2 = (unsigned char)atoi(argv[4]);
	unsigned char b2 = (unsigned char)atoi(argv[5]);
	printf("Replace in %s: (%d %d) - (%d %d)\n", szFilename, a1, b1, a2, b2);

	int nHandle;
	if ((nHandle = open( szFilename, FILEOPEN_FLAGS )) == -1)
	{
		printf("Could not open file\n");
		return -1;
	}

	unsigned char *buf = new unsigned char[LEVEL_SIZE];

	read(nHandle, buf, LEVEL_SIZE);

	for ( int i=0; i<LEVEL_SIZE; i+=2 )
	{
		if (buf[i]==a1 && buf[i+1]==b1)
		{
			printf("%d (%d %d)\n", i, i%(4*LEVEL_WIDTH), i/(4*LEVEL_WIDTH));
			buf[i  ] = a2;
			buf[i+1] = b2;
		}
	}

	lseek(nHandle, 0, SEEK_SET);

	write(nHandle, buf, LEVEL_SIZE);

	delete[] buf;
	
	close(nHandle);

	return 0;
}
