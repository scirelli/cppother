/*--------------------------------------------------------------------------*/
// This is just here for convenience
/*--------------------------------------------------------------------------*/
#include "djgraph.h"
#include "djimage.h"
#include "djinput.h"
#include "djlog.h"
#include "djsound.h"
#include "djstring.h"
#include "djtime.h"
#include "djtypes.h"
/*--------------------------------------------------------------------------*/
