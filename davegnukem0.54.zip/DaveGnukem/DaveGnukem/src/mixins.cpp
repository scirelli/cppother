/*--------------------------------------------------------------------------*/
/* mixins.cpp */
/* David Joffe 1999/02 */
/* "mixins"; not intended to be classes on their own, just contain */
/* standalone characteristics that others can multiple-inherit from to get */
/* that behaviour */
/*
mixins.cpp

Copyright (C) 1999-2001 David Joffe

License: GNU GPL Version 2 (*not* "later versions")
*/

/*--------------------------------------------------------------------------*/
#include "mixins.h"
#include <string.h>

CNamed::CNamed()
{
   m_szName = NULL;
}

void CNamed::SetName( char * szName )
{
   if ( m_szName != NULL )
   {
      delete[] m_szName;
      m_szName = NULL;
   }

   if ( NULL == szName )
      return;

   m_szName = new char[ strlen(szName) + 1 ];
   strcpy( m_szName, szName );

}

char * CNamed::GetName()
{
   return m_szName;
}

