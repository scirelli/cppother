/*--------------------------------------------------------------------------*/
/* David Joffe '95/07/20 */
/*
menu.cpp

Copyright (C) 1995-2001 David Joffe

License: GNU GPL Version 2 (*not* "later versions")
*/

#include "menu.h"

#include "graph.h"

#include <string.h>

#include "djinput.h"
#include "djtime.h"


int option;

void menu_move( CMenu *pMenu, int& option, int diff, unsigned char cCursor )
{
	djgSetColorFore( pVisBack, pMenu->m_clrBack );
	djgDrawBox( pVisBack, pMenu->m_xOffset+8, pMenu->m_yOffset+option*8, 8, 8 );
	
	int iOptionPrev = option;
	option += diff;
	if (option < 1)                    option = 1;
	if (option > (pMenu->m_iSize - 2)) option = (pMenu->m_iSize - 2);

	// Play a sound
	if (option != iOptionPrev) djSoundPlay( pMenu->m_iSoundMove );

	// Redraw the menu cursor
	djgDrawImageAlpha( pVisBack, g_pFont8x8, ((int)cCursor%32)*8, ((int)cCursor/32)*8, pMenu->m_xOffset+8, pMenu->m_yOffset+8*option, 8, 8 );
	
	GraphFlip();
}
/*--------------------------------------------------------------------------*/


/*--------------------------------------------------------------------------*/
int do_menu( CMenu *pMenu )
{
	int option;
	int i;
	int size;
	unsigned char * szCursor;

	// Initialize cursor animation
	szCursor = pMenu->m_szCursor;
	
	// set default option
	option = 1;
	
	// calculate size of menu
	for ( size=0; pMenu->m_items[size].m_szText != NULL; size++ )
		;
	
	pMenu->m_iSize = size;
	
	// Calculate position of menu on screen, if "asked" to do so (== -1)
	if ( pMenu->m_xOffset == -1 )
		pMenu->m_xOffset = 8 * (20 - (strlen(pMenu->m_items[0].m_szText) / 2));
	if ( pMenu->m_yOffset == -1 )
		pMenu->m_yOffset = 8 * (12 - (size / 2));
	
	// draw menu
	for ( i=0; i<size; i++ )
	{
		// Draw blank underneath menu (FIXME: Somehow should be able to be image underneath)

		djgSetColorFore( pVisBack, pMenu->m_clrBack );
		djgDrawBox( pVisBack, pMenu->m_xOffset, pMenu->m_yOffset+i*8, 8 * strlen(pMenu->m_items[i].m_szText), 8 );

		// Draw menu text
		GraphDrawString( pVisBack, g_pFont8x8, pMenu->m_xOffset, pMenu->m_yOffset+i*8, (unsigned char*)pMenu->m_items[i].m_szText );
	}
	menu_move( pMenu, option, 0, *szCursor );
	

	
	// Wait for user to let go of escape, if he is pressing it
	djiWaitForKeyUp( DJKEY_ESC );
	
	

	// We want to maintain 10 fps on menu cursor animations
	float fTimeFrame = (1.0f / 10.0f);

	// Start out by being at next time
	float fTimeNext = djTimeGetTime();
	float fTimeNow = fTimeNext;
	
	bool bmenurunning = true;
	
	do
	{
		fTimeNow = djTimeGetTime();
		bool bForceUpdate = false;
		// If we're already behind, just force us to get there
		if (fTimeNext < fTimeNow)
		{
			//printf( "slow\n" );
			fTimeNext = fTimeNow;
			bForceUpdate = true;
		}
		
		while (bmenurunning && (fTimeNow<fTimeNext || bForceUpdate)) // until we reach next frames time
		{
			SDL_Delay(10);
			
			// poll keys
			djiPoll();
			
			// up arrow
			static bool bkeyup = false;
			if ( (g_iKeys[DJKEY_UP]) && (bkeyup == false) )
			{
				menu_move( pMenu, option, -1, *szCursor );
			}
			bkeyup = (bool)(g_iKeys[DJKEY_UP]!=0);
			
			// down arrow
			static bool bkeydown = false;
			if ( (g_iKeys[DJKEY_DOWN]) && (bkeydown == false) )
			{
				menu_move( pMenu, option, 1, *szCursor );
			}
			bkeydown = (bool)(g_iKeys[DJKEY_DOWN] != 0);
			
 			// home key
			if (g_iKeys[DJKEY_HOME])
				menu_move( pMenu, option, -option, *szCursor );
			
			// end key
			if (g_iKeys[DJKEY_END])
				menu_move( pMenu, option, -option + pMenu->m_iSize - 1, *szCursor );
			
			// enter
			if (g_iKeys[DJKEY_ENTER])
				bmenurunning = 0;
			
			// escape
			if (g_iKeys[DJKEY_ESC])
			{
				option = -1;
				bmenurunning = 0;
			}
			
			
			fTimeNow = djTimeGetTime();
			bForceUpdate = false;
		}
		fTimeNext = fTimeNow + fTimeFrame;
		
		
		if (bmenurunning)
		{
			// Animate cursor
			szCursor++;
			if (*szCursor == 0)
				szCursor = pMenu->m_szCursor;
			
			menu_move( pMenu, option, 0, *szCursor );
		}
		
	} while (bmenurunning);
	
	// Wait for user to let go of escape or enter
	if (option == -1)
		djiWaitForKeyUp(DJKEY_ESC);
	else
		djiWaitForKeyUp(DJKEY_ENTER);
	
	
	return option;
}
/*--------------------------------------------------------------------------*/
