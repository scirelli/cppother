/*
djstring.cpp

Copyright (C) 1998-2001 David Joffe

License: GNU GPL Version 2 (*not* "later versions")
*/

#include "djstring.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

char * djStrDeepCopy( const char * src )
{
	char * temp;
	
	if ( NULL == src )
		return NULL;
	
	temp = new char[ strlen(src) + 1 ];
	strcpy( temp, src );
	
	return temp;
}

char * djStrDeepCopy( const char * src, int n )
{
	char * temp;
	
	if ( NULL == src )
		return NULL;
	
	// FIXME: If src is shorter than n then allocate less
	temp = new char[ n + 1 ];
	strncpy( temp, src, n );
	temp[n] = '\0';
	
	return temp;
}

// i starts counting at 1
char * djStrPart( char * str, int i, char * delim )
{
	int pos, count, length;
	
	if ( i < 1 )
		return NULL;

	

	
	pos = 0;
	count = 0;
	while ( ( count < i - 1 ) && ( pos < (int)strlen( str ) ) )
	{
		while ( (NULL == strchr( delim, str[pos] )) && (pos < (int)strlen( str )) )
		{
			//	 printf( "[%c]", str[pos] );
			pos++;
		}
		if ( pos < (int)strlen(str) )
		{
			pos++;
			count++;
		}
		//      printf( "\n" );
	}
	
	// if end of string reached before part i was reached
	if ( count != i - 1 )
		return NULL;
	
	// Determine length of substring required
	length = 0;
	while ( ((pos+length) < (int)strlen(str)) && (NULL == strchr( delim, str[pos+length] )) )
	{
		length++;
	}
	
	char * temp = NULL;
	temp = djStrDeepCopy( &str[pos], length );
	//   printf("String found (length %d) is [%s]\n", length, temp );
	
	return temp;
}

void djStrToLower( char * str )
{
	for ( int i=0; i<(int)strlen(str); i++ )
	{
		if ((str[i] >= 'A') && (str[i] <= 'Z')) str[i] += 32;
	}
}
