/*
hiscores.cpp

Copyright (C) 2001 David Joffe

License: GNU GPL Version 2 (*not* "later versions")
*/

#include "hiscores.h"
#include "djtypes.h"
#include "menu.h"
#include "graph.h"
#include "djlog.h"
#include <stdio.h>
#include <string.h>
#include <vector>
using namespace std;

// Scores, sorted from highest to lowest
vector<SScore> g_aScores;

djImage *pImgHighScores=NULL;
struct SMenuItem instructionsHighScoreItems[] =
{
   { false, "{~~~~~~}" },
   { true,  "|  OK  |" },
   { false, "[~~~~~~]" },
   { false, NULL }     
};
unsigned char instructionsHighScoreCursor[] = { 128, 129, 130, 131, 0 };
CMenu HighScoresMenu;


void ShowHighScores()
{
	HighScoresMenu.m_iSize = 0;
	HighScoresMenu.m_items = instructionsHighScoreItems;
	HighScoresMenu.m_szCursor = instructionsHighScoreCursor;
	HighScoresMenu.m_clrBack = djColor(0,173,173);
	HighScoresMenu.m_xOffset = 220;
	HighScoresMenu.m_yOffset = 160;
	if (pImgHighScores==NULL)
	{
		if (NULL != (pImgHighScores = new djImage))
			pImgHighScores->Load(FILE_IMG_HIGHSCORES);
	}
	if (pImgHighScores)
	{
		djgDrawImage( pVisBack, pImgHighScores, 0, 0, pImgHighScores->Width(), pImgHighScores->Height() );

		for ( int i=0; i<(int)g_aScores.size(); i++ )
		{
			char buf[128];
			sprintf(buf, "%d  %d", i, g_aScores[i].nScore);
			GraphDrawString(pVisBack, g_pFont8x8, 24, 24+i*12, (unsigned char*)buf);
			sprintf(buf, "%s", g_aScores[i].szName);
			GraphDrawString(pVisBack, g_pFont8x8, 24+11*8, 24+i*12, (unsigned char*)buf);
		}

		GraphFlip();
		
		// Pop up high scores menu
		do_menu( &HighScoresMenu);
	}
}

bool LoadHighScores(const char *szFilename)
{
	g_aScores.clear();
	
	FILE *pIn = fopen(szFilename, "r");
	if (pIn==NULL)
	{
		djMSG("LoadHighScores: Failed to open file (%s): Creating default list\n", szFilename);
		AddHighScore("Todd", 40000);
		AddHighScore("Scott", 30000);
		AddHighScore("George", 20000);
		AddHighScore("Al", 10000);
		AddHighScore("David", 5000);
		return false;
	}
	
	char buf[512];
	
	fgets(buf, sizeof(buf), pIn);
	while (strlen(buf)>=1 && ((buf[strlen(buf)-1]=='\r') || (buf[strlen(buf)-1]=='\n')))
		buf[strlen(buf)-1] = '\0'; // strip newline character(s)
	int nEntries = 0;
	sscanf(buf, "%d", &nEntries);
	for ( int i=0; i<nEntries; i++ )
	{
		SScore Score;
		
		fgets(buf, sizeof(buf), pIn);
		while (strlen(buf)>=1 && ((buf[strlen(buf)-1]=='\r') || (buf[strlen(buf)-1]=='\n')))
			buf[strlen(buf)-1] = '\0'; // strip newline character(s)
		strcpy(Score.szName, buf);
		
		fgets(buf, sizeof(buf), pIn);
		while (strlen(buf)>=1 && ((buf[strlen(buf)-1]=='\r') || (buf[strlen(buf)-1]=='\n')))
			buf[strlen(buf)-1] = '\0'; // strip newline character(s)
		sscanf(buf, "%d", &Score.nScore);
		
		AddHighScore(Score.szName, Score.nScore);
	}
	
	fclose(pIn);
	
	return true;
}

bool SaveHighScores(const char *szFilename)
{
	FILE *pOut = fopen(szFilename, "w");
	if (pOut==NULL)
	{
		djMSG("SaveHighScores(%s): Failed to create file\n", szFilename);
		return false;
	}
	fprintf(pOut, "%d\n", MIN(g_aScores.size(), MAX_HIGHSCORES));
	for ( int i=0; i<(int)(MIN(g_aScores.size(), MAX_HIGHSCORES)); i++ )
	{
		fprintf(pOut, "%s\n", g_aScores[i].szName);
		fprintf(pOut, "%d\n", g_aScores[i].nScore);
	}
	fclose(pOut);
	return true;
}

bool IsNewHighScore(int nScore)
{
	if (nScore==0)
		return false;
	if (g_aScores.size()<MAX_HIGHSCORES)
		return true;
	for ( int i=0; i<(int)g_aScores.size(); i++ )
	{
		if (nScore>g_aScores[i].nScore)
			return true;
	}
	return false;
}

void AddHighScore(const char *szName, int nScore)
{
	for ( int i=0; i<(int)g_aScores.size(); i++ )
	{
		if (nScore>g_aScores[i].nScore)
		{
			SScore Score;
			Score.nScore = nScore;
			strcpy(Score.szName, szName);
			g_aScores.insert(g_aScores.begin()+i, Score);
			goto Leave;
		}
	}
	if (g_aScores.size()<MAX_HIGHSCORES)
	{
		SScore Score;
		Score.nScore = nScore;
		strcpy(Score.szName, szName);
		g_aScores.push_back(Score);
	}
Leave:
	while (g_aScores.size()>MAX_HIGHSCORES)
		g_aScores.pop_back();
}

void GetHighScore(int nIndex, SScore &Score)
{
	if (nIndex>=(int)g_aScores.size())
	{
		strcpy(Score.szName, "");
		Score.nScore = 0;
		return;
	}
	strcpy(Score.szName, g_aScores[nIndex].szName);
	Score.nScore = g_aScores[nIndex].nScore;
}
