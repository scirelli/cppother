/*!
\file    djlog.h
\brief   Debugging message "trace" helpers
\author  David Joffe

Copyright (C) 1998-2001 David Joffe

License: GNU GPL Version 2 (*not* "later versions")
*/
/*--------------------------------------------------------------------------*/
#ifndef _DJLOG_H_
#define _DJLOG_H_

#if defined(DEBUG) || defined(NDEBUG) || defined(_DEBUG)
#define TRACE log_message
#else
#define TRACE ;;
#endif

#define djMSG log_message

extern void log_message( const char * szFormat, ... );
extern void log_do_nothing( const char * szFormat, ... );

#endif

