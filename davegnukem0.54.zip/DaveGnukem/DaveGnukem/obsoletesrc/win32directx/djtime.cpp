/*--------------------------------------------------------------------------*/
// djtime.cpp
//
// Copyright (C) David Joffe 1999
//
// License: GNU GPL
//
// General time functions
/*--------------------------------------------------------------------------*/
#include "../djtime.h"
#include <string.h>
#include <windows.h>
#include <mmsystem.h>
/*--------------------------------------------------------------------------*/
//
// Win32 version
//
/*--------------------------------------------------------------------------*/
// Initialize the time system
void djTimeInit()
{
	// Windows NT / 2000 have a default timer resolution of 5 ms
	timeBeginPeriod(1);
}

// Shut down the time system
void djTimeDone()
{
	timeEndPeriod(1);
}

// return time of day in seconds
float djTimeGetTime()
{
	return ((float)timeGetTime() / 1000.0f);
}

