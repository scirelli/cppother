#pragma once
#include "IVehicle.h"

class CPlane : public IVehicle
{
public:
	CPlane(void);
	~CPlane(void);
};
