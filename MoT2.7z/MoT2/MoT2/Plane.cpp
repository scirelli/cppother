#include "StdAfx.h"
#include "Plane.h"

CPlane::CPlane(void)
{
	this->name = "Plane";
	this->distance = 0;
	this->symbol = '+';
}

CPlane::~CPlane(void)
{}