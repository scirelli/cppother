#include "StdAfx.h"
#include "Car.h"

CCar::CCar(void)
{
	this->name = "Car";
	this->distance = 0;
	this->symbol = 'o';
}

CCar::~CCar(void)
{
}
