#pragma once
#include "ivehicle.h"

class CCar : public IVehicle
{
public:
	CCar(void);
public:
	virtual ~CCar(void);
};
