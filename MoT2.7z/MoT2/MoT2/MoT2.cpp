// MoT.cpp : Defines the entry point for the console application.
//
#include "stdafx.h"
#include "Main.h"

using namespace std;

int _tmain(int argc, _TCHAR* argv[])
{
	Main m;
	m.questionUser();
	
	system("PAUSE");
	return EXIT_SUCCESS;
}